package com.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class LoginPage {
	WebDriver driver;

	
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
//		if(!driver.getTitle().equals("JPetStore Demo")) {
//			throw new IllegalStateException("This is not login Page. The current page is"+driver.getCurrentUrl());
//		}
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
	}
	
	@FindBy(xpath ="*//a[text()='Enter the Store']")
	WebElement enterStore;
	public void enterStore() {
		enterStore.click();
	}
	@FindBy(xpath ="*//a[text()='Sign In']")
	WebElement txt_signin;
	public void enterLogin() {
		txt_signin.click();
	}
	
	@FindBy(xpath ="*//input[@name='username']")
	WebElement txt_username;
	public void enterUsername(String username) {
		txt_username.sendKeys(username);
	}
	
	@FindBy(xpath ="*//input[@name='password']")
	WebElement txt_password;
	public void enterPassword(String password) {
		txt_password.clear();
		txt_password.sendKeys(password);
	}
	
	@FindBy(xpath ="*//input[@name='signon']")
	WebElement txt_signon;
	public void enterLogon() {
		txt_signon.click();
	}
	
	
}

package com.petstore;

import org.junit.runner.RunWith;



import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/Features/Petstore.feature",
glue = {"com.petstore"},
monochrome = true,
plugin = {"pretty",
		"json:target/JSONReports/pom_report.json",
		"junit:target/JunitReports/pom_report.xml",
		"html:target/HtmlReports/pom_report.html"
}
)
public class TestRunner {
	
}

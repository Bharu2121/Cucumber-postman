package com.petstore;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.Pages.HomePage;
import com.Pages.LoginPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class PetStoreSteps {
	WebDriver driver=null;
	LoginPage loginpage;
	HomePage homepage;
	@Given("broswer is open")
	public void broswer_is_open() {
	    System.out.println("Browser is open..");
	    System.out.println("browser opening...");
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}
	
	@Given("user is on login page")
	public void user_is_on_login_page() throws InterruptedException {
		loginpage=new LoginPage(driver);
	    System.out.println("User is on login page");
	    driver.get("https://petstore.octoperf.com/");
	    loginpage.enterStore();
	    loginpage.enterLogin();
	    Thread.sleep(2000);
	   
	}

	@When("user enters username as {string} and password as {string}")
	public void user_enters_username_and_password(String username,String password) throws InterruptedException {
	    System.out.println("User enters username and password");
	    //username
	    loginpage.enterUsername(username);
	    //password
	    loginpage.enterPassword(password);
	   Thread.sleep(2000);
	}

	@When("click on login button")
	public void click_on_login_button() throws InterruptedException {
	   System.out.println("User clicks on login button");
	   loginpage.enterLogon();
	}

	@Then("user sees message as {string}")
	public void verifyUser(String expectedMessage) throws InterruptedException {
	   homepage=new HomePage(driver);
	   System.out.println("validate the user is navigated to home page");
	   
	   if(expectedMessage.contains("Welcome")) {
	   System.out.println("User provides valid credentials...");
	   String welcome_text= homepage.verifyWelcomeContent();
	   assertTrue(welcome_text.equals(expectedMessage),"Verfication sucess....");
	   }
	   else if(expectedMessage.contains("Invalid username or password")){
	   System.out.println("User provides invalid credentials...");
	   String error_msg=homepage.errorInvalidCredentials();
	   assertEquals(error_msg,expectedMessage,"Invalid crdentials");
	  
	   }
	   else {
		   System.out.println("User provides empty credentials...either username or password");
		   String error_msg=homepage.errorEmptyCredentials();
		   assertEquals(error_msg, expectedMessage,"Empty crdentials");
	   }
	   Thread.sleep(3000);
	   driver.quit();
	}


}

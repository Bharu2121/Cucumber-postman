package excelDataPOM;

import static org.testng.Assert.assertEquals;


import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;
import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import com.Pages.HomePage;
import com.Pages.LoginPage;
import com.Utilities.DataReader;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class PageFactorySteps {
	WebDriver driver=null;
	LoginPage loginpage;
	HomePage homepage;
	List<HashMap<String, String>> datamap;
	String exp_res;
	@Given("user launch browser")
	public void broswer_is_open() {
	    System.out.println("Browser is open..");
	    System.out.println("browser opening...");
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}
	
	@Given("user opens URL {string}")
	public void opens_url(String url) throws InterruptedException {
		loginpage=new LoginPage(driver);
	    driver.get(url);
	    System.out.println("User is on login page");
	    loginpage.enterStore();
	    loginpage.enterLogin();
	    Thread.sleep(2000);
	   
	}

	@When("user enters username and password by using excel {string}")
	public void user_enters_username_and_password(String rows) throws InterruptedException {
	    System.out.println("User enters username and password");
	
	        datamap=DataReader.data("C:\\Users\\HP\\OneDrive\\excelData.xlsx", "Sheet1");

	        int index=Integer.parseInt(rows)-1;
	        String email= datamap.get(index).get("username");
	        String pwd= datamap.get(index).get("password");
	        exp_res= datamap.get(index).get("expectedMessage");

	    //username
	    loginpage.enterUsername(email);
	    //password
	    loginpage.enterPassword(pwd);
	   Thread.sleep(2000);
	}

	@When("click on login")
	public void click_on_login_button() throws InterruptedException {
	   System.out.println("User clicks on login button");
	   loginpage.enterLogon();
	   Thread.sleep(2000);
	}

	@Then("user checks for valid login")
	public void verifyUser() throws InterruptedException {
		String expectedMessage=exp_res;
		homepage=new HomePage(driver);
	   System.out.println("validate the user is navigated to home page");
	   
	   if(expectedMessage.contains("Welcome")) {
	   System.out.println("User provides valid credentials...");
	   String welcome_text= homepage.verifyWelcomeContent();
	   System.out.println(welcome_text);
	   assertTrue(welcome_text.contains(expectedMessage),"Verfication sucess....");
	   }
	   else if(expectedMessage.contains("Invalid username or password")){
	   System.out.println("User provides invalid credentials...");
	   String error_msg=homepage.errorInvalidCredentials();
	   System.out.println(error_msg);
	   assertEquals(error_msg,expectedMessage,"Invalid crdentials");
	  
	   }
	   else {
		   System.out.println("User provides empty credentials...either username or password");
		   String error_msg=homepage.errorEmptyCredentials();
		   System.out.println(error_msg);
		   assertEquals(error_msg, expectedMessage,"Empty crdentials");
	   }
	   Thread.sleep(3000);
	   driver.close();
	}


}

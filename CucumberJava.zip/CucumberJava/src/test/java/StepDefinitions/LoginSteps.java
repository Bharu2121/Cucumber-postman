package StepDefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginSteps {
	WebDriver driver=null;
	@Given("broswer is open")
	public void broswer_is_open() {
	    System.out.println("Browser is open..");
	    System.out.println("browser opening...");
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}
	
	@Given("user is on login page")
	public void user_is_on_login_page() throws InterruptedException {
	    System.out.println("User is on login page");
	    driver.get("https://petstore.octoperf.com/");
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("*//a[text()='Enter the Store']")).click();
	    driver.findElement(By.xpath("*//a[text()='Sign In']")).click();
	}

	@When("^user enters (.*) and (.*)$")
	public void user_enters_username_and_password(String username,String password) throws InterruptedException {
	    System.out.println("User enters username and password");
	    //username
	    driver.findElement(By.xpath("*//input[@name='username']")).sendKeys(username);
	    //password
	   WebElement password_ele= driver.findElement(By.xpath("*//input[@name='password']"));
	   password_ele.clear();
	   password_ele.sendKeys(password);
	   Thread.sleep(2000);
	}

	@When("click on login button")
	public void click_on_login_button() throws InterruptedException {
	   System.out.println("User clicks on login button");
	   driver.findElement(By.xpath("*//input[@name='signon']")).click();
	}

	@Then("^user sees (.*)$")
	public void verifyUser(String expectedMessage) throws InterruptedException {
	   System.out.println("validate the user is navigated to home page");
	   
	   if(expectedMessage.contains("Welcome")) {
	   System.out.println("User provides valid credentials...");
	   String welcome_text= driver.findElement(By.id("WelcomeContent")).getText();
	   assertTrue(welcome_text.equals(expectedMessage),"Verfication sucess....");
	   }
	   else if(expectedMessage.contains("Invalid username or password")){
	   System.out.println("User provides invalid credentials...");
	   String error_msg=driver.findElement(By.xpath("//*[text()='Invalid username or password.  Signon failed.']")).getText();
	   assertEquals(error_msg,expectedMessage,"Invalid crdentials");
	  
	   }
	   else {
		   System.out.println("User provides empty credentials...either username or password");
		   String error_msg=driver.findElement(By.xpath("*//p[text()='Please enter your username and password.']")).getText();
		   assertEquals(error_msg, expectedMessage,"Empty crdentials");
	   }
	   Thread.sleep(3000);
	   driver.quit();
	}


}

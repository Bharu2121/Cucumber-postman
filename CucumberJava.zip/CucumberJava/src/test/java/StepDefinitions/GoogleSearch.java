package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleSearch {
	WebDriver driver=null;
	@Given("browser is open")
	public void browser_is_open() {
	 
		System.out.println("browser opening...");
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.manage().window().maximize();
	}

	@Given("user is on google search page")
	public void user_is_on_google_search_page() throws InterruptedException {
	   System.out.println("user is on google search page");
	   driver.get("https://www.google.com/");
	   Thread.sleep(3000);
	}

	@When("user enters a text in search box")
	public void user_enters_a_text_in_search_box() throws InterruptedException {
		System.out.println("user enters a text in search box");
		driver.findElement(By.id("APjFqb")).sendKeys("Baba songs");
		 Thread.sleep(3000);
	}

	@When("clicks on enter")
	public void clicks_on_enter()throws InterruptedException {
		System.out.println("clicks on enter");
		driver.findElement(By.id("APjFqb")).sendKeys(Keys.ENTER);
		 Thread.sleep(3000);
	}

	@Then("user is navigated to search results")
	public void user_is_navigated_to_search_results() throws InterruptedException{
		System.out.println("Validating user is navigated to particular search box");
		 Thread.sleep(3000);
//		WebElement validate=driver.findElement(By.xpath("*//div[text()='Songs / Baba']"));
//		String validate_text=validate.getText();
//		if(validate_text.contains("baba"))
//			System.out.println("User is navigated to the search page successfully....");
		 driver.getPageSource().contains("Baba");
		 Thread.sleep(3000);
		 driver.quit();
	}



}

package StepDefinitions;

import org.junit.runner.RunWith;



import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/Features/Login.feature",
glue = {"StepDefinitions"},
monochrome = true,
plugin = {"pretty",
		"json:target/JSONReports/parameterization_report.json",
		"junit:target/JunitReports/parameterization_report.xml",
		"html:target/HtmlReports/parameterization_report.html"
}
)
public class TestRunner {
	
}

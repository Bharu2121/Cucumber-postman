package POMSteps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	WebDriver driver;
	By enterStore=By.xpath("*//a[text()='Enter the Store']");
	By txt_signin=By.xpath("*//a[text()='Sign In']");
	By txt_username=By.xpath("*//input[@name='username']");
	By txt_password=By.xpath("*//input[@name='password']");
	By txt_signon=By.xpath("*//input[@name='signon']");
	By welcome_content=By.id("WelcomeContent");
	By error_invalid_credentials=By.xpath("//*[text()='Invalid username or password.  Signon failed.']");
	By error_empty_credentials=By.xpath("*//p[text()='Please enter your username and password.']");
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		if(!driver.getTitle().equals("JPetStore Demo")) {
			throw new IllegalStateException("This is not Login Page. The current page is"+driver.getCurrentUrl());
		}
	}
	public void enterStore() {
		driver.findElement(enterStore).click();
	}
	public void enterLogin() {
		driver.findElement(txt_signin).click();
	}
	
	public void enterUsername(String username) {
		driver.findElement(txt_username).sendKeys(username);
	}
	
	public void enterPassword(String password) {
		WebElement psw= driver.findElement(txt_password);
		psw.clear();
		psw.sendKeys(password);
	}
	
	public void enterLogon() {
		driver.findElement(txt_signon).click();
	}
	
	public String verifyWelcomeContent() {
		 return driver.findElement(welcome_content).getText();
	}
	
	public String errorEmptyCredentials( ) {
		 return driver.findElement(error_empty_credentials).getText();
	}
	
	public String errorInvalidCredentials() {
		return driver.findElement(error_invalid_credentials).getText();
	}
}

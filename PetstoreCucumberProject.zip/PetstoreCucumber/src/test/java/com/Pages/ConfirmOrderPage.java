package com.Pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
public class ConfirmOrderPage {
	WebDriver driver;

	public ConfirmOrderPage(WebDriver driver) {
		//super();
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
	}
	
	@FindBy(xpath = "//*[@id='QuickLinks']/a[4]")
	WebElement selectCategory;
	public WebElement selectCategory(){
		return selectItem;
	}
	
	@FindBy(xpath = "//*[@id='Catalog']/table/tbody/tr[2]/td[1]/a")
	WebElement selectItem;
	public WebElement selectItem(){
		return selectItem;
	}
	
	@FindBy(xpath = "(*//a[text()='Add to Cart'])[1]")
	WebElement addtocart;
	public WebElement addtoCart(){
		return addtocart;
	}
	
	@FindBy(xpath = "*//input[@name='updateCartQuantities']")
	WebElement updatecart;
	public WebElement updateCart(){
		return updatecart;
	}
	
	@FindBy(xpath = "//*[@id='Cart']/a")
	WebElement proceedtopay;
	public WebElement checkOutBtn(){
		return proceedtopay;
	}
	
	@FindBy(xpath = "//*[@id='Catalog']/form/table/tbody/tr[6]/td[2]/input")
	WebElement validateaddress;
	public WebElement validateAddress(){
		return validateaddress;
	}

	@FindBy(xpath = "//*[@id='Catalog']/form/input")
	WebElement continuebtn;
	public WebElement pressContinue(){
		return continuebtn;
	}
	@FindBy(xpath = "//*[@id='Catalog']/a")
	WebElement confirm;
	public WebElement Confirmbtn(){
		return confirm;
	}
	@FindBy(xpath = "//*[@id='Content']/ul/li")
	WebElement checkout;
	public WebElement verifyCheckout(){
		return checkout;
	}
	
	@FindBy(xpath = "//*[@id='Catalog']/table/tbody/tr[1]/th")
	WebElement orderID;
	public WebElement orderID(){
		return orderID;
	}

}

package com.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class SearchPage {
	WebDriver driver;

	public SearchPage(WebDriver driver) {
		//super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//*[@id=\"SearchContent\"]/form/input[1]")
	WebElement search;
	public void searchItem(String searchitem) {
		search.sendKeys(searchitem);
	}
	@FindBy(xpath = "//*[@id=\"SearchContent\"]/form/input[2]")
	WebElement clicksearch;
	public void clickSearch() {
		clicksearch.click();
	}
	@FindBy(xpath="//*[@id=\"Content\"]/ul[1]/li")
	WebElement search_error;
	public WebElement searchError() {
		 return search_error;
	}
	@FindBy(xpath = "/html/body/div[2]/div[2]/table/tbody/tr[1]/th[2]")
	WebElement check;
	public boolean productId() {
		return check.isDisplayed();
	}

}

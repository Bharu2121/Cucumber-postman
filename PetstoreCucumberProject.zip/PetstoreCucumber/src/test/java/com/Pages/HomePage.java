package com.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class HomePage {
	

	WebDriver driver;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
		if(!driver.getTitle().equals("JPetStore Demo")) {
			throw new IllegalStateException("This is not Home Page. The current page is"+driver.getCurrentUrl());
		}
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
	}
	
	@FindBy(id="WelcomeContent")
	WebElement welcome_content;
	public String verifyWelcomeContent() {
		 return welcome_content.getText();
	}
	
	@FindBy(xpath ="//*[text()='Invalid username or password.  Signon failed.']")
	WebElement error_invalid_credentials;
	public String errorInvalidCredentials() {
		return error_invalid_credentials.getText();
	}
	
	@FindBy(xpath ="*//p[text()='Please enter your username and password.']")
	WebElement error_empty_credentials;
	public String errorEmptyCredentials( ) {
		 return error_empty_credentials.getText();
	}
	
	
	
}

package com.TestRunner;

import org.junit.runner.RunWith;

import org.testng.annotations.DataProvider;

//
import io.cucumber.junit.Cucumber;
//import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


//@RunWith(Cucumber.class)
@CucumberOptions(features =  "src/test/resources/Features/Petstore.feature",//"src/test/resources/Features/Search.feature"},
glue = {"com.StepDefinitions"},

plugin = {"pretty",
		"json:target/JSONReports/petstore_report.json",
		"junit:target/JunitReports/petstore_report.xml",
		"html:target/HtmlReports/petstore_report.html",
		"rerun:target/rerun.txt",
		"me.jvt.cucumber.report.PrettyReports:target/cucumber"
		
} 
,monochrome = true,
publish = true
//,tags ="@overall"
)
public class TestRunner1 extends AbstractTestNGCucumberTests{
	  @Override
	    @DataProvider(parallel = true)
	    public Object[][] scenarios(){
	    	return super.scenarios();
	    }
}

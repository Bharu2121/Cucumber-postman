package Steps2;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class SearchSteps {
	WebDriver driver;
	@Given("user opens browser")
	public void user_opens_browser() {
	   System.out.println("user opens the browser");
	   WebDriverManager.chromedriver().setup();
	   ChromeOptions opt=new ChromeOptions();
	   opt.addArguments("--start-maximized");
	   driver=new ChromeDriver(opt);
	   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   driver.manage().window().maximize();
	   
	}

	@Given("user is on search page")
	public void user_is_on_search_page() throws InterruptedException {
	   System.out.println("user is on search page");
	   driver.get("https://www.google.com/");
	   Thread.sleep(3000);
	}
	
	@When("^user enters a valid search as (.*)$")
	public void user_enters_a_valid_search_as(String validinput) {
	  System.out.println("valid input: "+validinput);
	  driver.findElement(By.name("q")).sendKeys(validinput,Keys.ENTER);
	}

	
	@Then("user should sees the results as {string}")
	public void user_should_sees_the_results(String msg) throws InterruptedException {
	   System.out.println("Search results....."+msg);
	   Thread.sleep(3000);
	   driver.close();
	}



}

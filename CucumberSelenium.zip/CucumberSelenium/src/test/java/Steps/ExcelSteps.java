package Steps;


import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ExcelSteps {
	WebDriver driver;
	String expectedmsg;
	String search;
	List<HashMap<String, String>> datamap;
	@Given("user opens browser")
	public void user_opens_browser() {
		System.out.println("user opens the browser");
		   WebDriverManager.chromedriver().setup();
		   ChromeOptions opt=new ChromeOptions();
		   opt.addArguments("--start-maximized");
		   driver=new ChromeDriver(opt);
		   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		   driver.manage().window().maximize();
	}
	@Given("user is on search page")
	public void user_is_on_search_page() throws InterruptedException {
		 System.out.println("user is on search page");
		   driver.get("https://www.google.com/");
		   Thread.sleep(3000);
	}
	@When("user enters a valid search using excel {string}")
	public void user_enters_a_valid_search_using_excel(String rows) {
	   datamap=DataReader.data("src\\test\\resources\\Feature\\searchData.xlsx", "Sheet1");  //path and sheet name
	   int index=Integer.parseInt(rows)-1; //rows--1-1=0
	   search=datamap.get(index).get("search_data");  //0->search_data
	   expectedmsg=datamap.get(index).get("expectedMessage");  //0->expectedmsg
	   System.out.println("The search input is "+search);
	   driver.findElement(By.name("q")).sendKeys(search,Keys.ENTER);
	}
	@Then("user should sees the results")
	public void user_should_sees_the_results() throws InterruptedException {
		  System.out.println("Search results....."+expectedmsg);
		   Thread.sleep(3000);
		   driver.close();
	}
}

package Steps;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/Feature/excellogin.feature",
glue= "Steps",

monochrome=true,
plugin = {"pretty","html:HTMLReports/html_report.html",
		"json:JSONReports/json_report.json",
		"junit:XMLReports/xml_report.xml"}
)
public class TestRunner {

}
